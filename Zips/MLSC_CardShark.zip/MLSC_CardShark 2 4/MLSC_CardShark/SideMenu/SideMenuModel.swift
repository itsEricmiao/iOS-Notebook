//
//  SideMenuModel.swift
//  MLSC_CardShark
//
//  Created by Eric Miao on 12/11/21.
//

import Foundation
import UIKit

struct SideMenuModel {
    var icon: UIImage
    var title: String
}
