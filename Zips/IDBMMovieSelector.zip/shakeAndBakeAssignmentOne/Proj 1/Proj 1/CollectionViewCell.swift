//
//  CollectionViewCell.swift
//  Proj 1
//
//  Created by Joshua Sylvester on 9/9/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
