The project is contained within this zip folder. But I've also included the GitHub link if there are  issues with the zipped project. I've also included a video in this zip of the app running on a physical device, email jsylvester@smu.edu if you have issues watching it. 

Team Name: shakeAndBake
Team Members:
Joshua Sylvester, Canon Ellis, Eric Miao

Versioning:
- Developed on Xcode version: 12.5.1
- Tested on a physical iPhone 11 running iOS 14.6
- Used personal development license

GitHub (if needed):
https://github.com/sillyvester/Proj-1
