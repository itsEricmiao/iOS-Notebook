Lab4 Mobile Sensing
Fall 2021
Group Members: Joshua Sylvester, Canon Ellis, Eric Miao

Notes on running the app:
- I took out openCV before submitting since that's what we did on the ICA. Let us know if you have issues and we can send the whole thing zipped with openCV. 
- The heart rate detector works best on older iPhones with smaller cameras and torches. We got the best results on an iPhone SE. Testing on a newer iPhone 11 often lead to inconclusive results. When running on the iPhone SE typically a finger worked but for the best results put the phone screendown and use your thumb with the tip of your thumb on the camera-lens and the base of the thumb on the torch.

